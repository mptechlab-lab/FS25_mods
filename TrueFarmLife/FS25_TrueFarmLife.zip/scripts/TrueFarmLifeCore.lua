-- True Farm Life central coordinator.
-- Modules report causes and effects here; persistent vehicle state remains stored
-- by the vehicle specialization, which preserves FS25 savegame compatibility.

TrueFarmLifeCore = {}
local TrueFarmLifeCore_mt = Class(TrueFarmLifeCore)

TrueFarmLifeCore.SYSTEMS = {
    mechanics = true,
    weatherImpact = true,
    inspections = true,
    consequences = true,
    diagnostics = true
}

function TrueFarmLifeCore.new(mission)
    local self = setmetatable({}, TrueFarmLifeCore_mt)
    self.mission = mission
    self.eventLog = {}
    self.statistics = {faults = 0, inspections = 0, services = 0, periods = 0, wetPeriods = 0}
    return self
end

function TrueFarmLifeCore:onStartMission()
    if self.mission:getIsServer() then
        g_messageCenter:subscribe(MessageType.PERIOD_CHANGED, self.onPeriodChanged, self)
    end
    self:record("system", "True Farm Life central coordinator started")
end

function TrueFarmLifeCore:deleteMap()
    g_messageCenter:unsubscribeAll(self)
end

function TrueFarmLifeCore:isEnabled(name)
    return TrueFarmLifeCore.SYSTEMS[name] == true
end

function TrueFarmLifeCore:record(kind, message, vehicle)
    local hours = 0
    if vehicle ~= nil and vehicle.spec_trueFarmLifeCondition ~= nil then
        hours = vehicle.spec_trueFarmLifeCondition.operatingHours or 0
    end
    table.insert(self.eventLog, 1, {kind = kind, message = message, hours = hours})
    if #self.eventLog > 80 then table.remove(self.eventLog) end
end

function TrueFarmLifeCore:recordVehicleEvent(vehicle, kind, message)
    self:record(kind, message, vehicle)
    if kind == "fault" then self.statistics.faults = self.statistics.faults + 1 end
    if kind == "inspection" then self.statistics.inspections = self.statistics.inspections + 1 end
    if kind == "service" then self.statistics.services = self.statistics.services + 1 end
end

function TrueFarmLifeCore:onPeriodChanged()
    self.statistics.periods = self.statistics.periods + 1
    local weather = self.mission.environment ~= nil and self.mission.environment.weather or nil
    if weather ~= nil and weather:getRainFallScale() > 0.10 then self.statistics.wetPeriods = self.statistics.wetPeriods + 1 end
    self:record("period", "Farm period advanced; long-term conditions updated")
end

