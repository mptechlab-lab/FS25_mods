-- Central balance profiles. The active profile is authoritative on the server.
-- Change DEFAULT_PROFILE before starting a savegame if a permanent default is desired.

TrueFarmLifeProfiles = {}

TrueFarmLifeProfiles.ORDER = {"REALISTIC", "HARDCORE", "SIMULATION", "ULTRA"}
TrueFarmLifeProfiles.DEFAULT_PROFILE = "SIMULATION"
TrueFarmLifeProfiles.activeProfile = TrueFarmLifeProfiles.DEFAULT_PROFILE

TrueFarmLifeProfiles.DATA = {
    REALISTIC = {wearMultiplier = 0.75, failureMultiplier = 0.45, repairCostMultiplier = 0.80, rainWorkloadMultiplier = 0.25, wetTractionPenalty = 0.04, insuranceAnnualRate = 0.002, blockWetFieldWork = false},
    HARDCORE = {wearMultiplier = 1.25, failureMultiplier = 1.20, repairCostMultiplier = 1.15, rainWorkloadMultiplier = 0.60, wetTractionPenalty = 0.10, insuranceAnnualRate = 0.004, blockWetFieldWork = false},
    SIMULATION = {wearMultiplier = 1.00, failureMultiplier = 0.85, repairCostMultiplier = 1.00, rainWorkloadMultiplier = 0.45, wetTractionPenalty = 0.07, insuranceAnnualRate = 0.003, blockWetFieldWork = false},
    ULTRA = {wearMultiplier = 1.75, failureMultiplier = 2.20, repairCostMultiplier = 1.45, rainWorkloadMultiplier = 1.00, wetTractionPenalty = 0.18, insuranceAnnualRate = 0.006, blockWetFieldWork = true}
}

function TrueFarmLifeProfiles.getActive()
    return TrueFarmLifeProfiles.DATA[TrueFarmLifeProfiles.activeProfile]
end

function TrueFarmLifeProfiles.getName()
    return TrueFarmLifeProfiles.activeProfile
end

function TrueFarmLifeProfiles.cycle()
    for index, name in ipairs(TrueFarmLifeProfiles.ORDER) do
        if name == TrueFarmLifeProfiles.activeProfile then
            TrueFarmLifeProfiles.activeProfile = TrueFarmLifeProfiles.ORDER[index % #TrueFarmLifeProfiles.ORDER + 1]
            return TrueFarmLifeProfiles.activeProfile
        end
    end
    TrueFarmLifeProfiles.activeProfile = TrueFarmLifeProfiles.DEFAULT_PROFILE
    return TrueFarmLifeProfiles.activeProfile
end
