-- Periodic fixed costs for machinery. The base game remains responsible for loans,
-- leasing, wages, fuel, seed, fertilizer and production-chain accounting.

TrueFarmLifeEconomy = {}
local TrueFarmLifeEconomy_mt = Class(TrueFarmLifeEconomy)

function TrueFarmLifeEconomy.new(mission)
    local self = setmetatable({}, TrueFarmLifeEconomy_mt)
    self.mission = mission
    return self
end

function TrueFarmLifeEconomy:onStartMission()
    if self.mission:getIsServer() then
        g_messageCenter:subscribe(MessageType.PERIOD_CHANGED, self.onPeriodChanged, self)
    end
end

function TrueFarmLifeEconomy:deleteMap()
    g_messageCenter:unsubscribeAll(self)
end

function TrueFarmLifeEconomy:onPeriodChanged()
    local vehicleSystem = self.mission.vehicleSystem
    if vehicleSystem == nil or vehicleSystem.vehicles == nil then
        return
    end

    local profile = TrueFarmLifeProfiles.getActive()
    local periodsPerYear = math.max((self.mission.environment and self.mission.environment.periodsPerYear) or 12, 1)
    local insuranceByFarm = {}

    for _, vehicle in ipairs(vehicleSystem.vehicles) do
        if vehicle.getOwnerFarmId ~= nil and vehicle.getPrice ~= nil and vehicle.propertyState ~= VehiclePropertyState.MISSION then
            local farmId = vehicle:getOwnerFarmId()
            if farmId ~= nil and farmId > 0 then
                local periodCost = vehicle:getPrice() * profile.insuranceAnnualRate / periodsPerYear
                insuranceByFarm[farmId] = (insuranceByFarm[farmId] or 0) + periodCost
            end
        end

        -- Standstill is not free: batteries self-discharge between seasonal periods.
        -- The loss is deliberately small, but becomes relevant on neglected machinery.
        local condition = vehicle["spec_" .. g_trueFarmLifeModName .. ".trueFarmLifeCondition"]
        if condition ~= nil and (vehicle.getIsMotorStarted == nil or not vehicle:getIsMotorStarted()) then
            local loss = 0.006 + (1 - condition.alternator) * 0.010
            condition.battery = math.max(0, condition.battery - loss)
            if vehicle.isServer and condition.dirtyFlag ~= nil then
                vehicle:raiseDirtyFlags(condition.dirtyFlag)
            end
        end
    end

    for farmId, cost in pairs(insuranceByFarm) do
        if cost > 0 then
            self.mission:addMoney(-cost, farmId, MoneyType.VEHICLE_RUNNING_COSTS, true, true)
        end
    end
end
