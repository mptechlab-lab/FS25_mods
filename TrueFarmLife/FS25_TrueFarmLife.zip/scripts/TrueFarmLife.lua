-- True Farm Life - bootstrap and global vehicle-type injection.
-- This mod deliberately extends base-game vehicle types instead of editing vehicle XML files.

TrueFarmLife = {}
TrueFarmLife.MOD_NAME = g_currentModName
TrueFarmLife.MOD_DIRECTORY = g_currentModDirectory

g_trueFarmLifeModName = TrueFarmLife.MOD_NAME

source(Utils.getFilename("scripts/TrueFarmLifeProfiles.lua", TrueFarmLife.MOD_DIRECTORY))
source(Utils.getFilename("scripts/TrueFarmLifeCore.lua", TrueFarmLife.MOD_DIRECTORY))
source(Utils.getFilename("scripts/TrueFarmLifeEconomy.lua", TrueFarmLife.MOD_DIRECTORY))

local isRunByTool = g_iconGenerator ~= nil

local function loadMission(mission)
    local economy = TrueFarmLifeEconomy.new(mission)
    local core = TrueFarmLifeCore.new(mission)
    TrueFarmLife.economy = economy
    TrueFarmLife.core = core
    addModEventListener(economy)
    addModEventListener(core)
end

local function startMission(mission)
    if TrueFarmLife.economy ~= nil then
        TrueFarmLife.economy:onStartMission()
    end
    if TrueFarmLife.core ~= nil then
        TrueFarmLife.core:onStartMission()
    end
end

local function installConditionSpecialization(typeManager)
    if typeManager.typeName ~= "vehicle" then
        return
    end

    local specializationName = TrueFarmLife.MOD_NAME .. ".trueFarmLifeCondition"
    if g_specializationManager:getSpecializationByName(specializationName) == nil then
        g_specializationManager:addSpecialization(
            "trueFarmLifeCondition",
            "TrueFarmLifeCondition",
            Utils.getFilename("scripts/specializations/TrueFarmLifeCondition.lua", TrueFarmLife.MOD_DIRECTORY),
            nil
        )
    end

    for typeName, typeEntry in pairs(g_vehicleTypeManager:getTypes()) do
        local hasMotor = SpecializationUtil.hasSpecialization(Motorized, typeEntry.specializations)
        local hasWearable = SpecializationUtil.hasSpecialization(Wearable, typeEntry.specializations)

        -- Motorized machines receive drivetrain failure logic; implements receive work-part logic.
        if hasMotor or hasWearable then
            g_vehicleTypeManager:addSpecialization(typeName, specializationName)
        end
    end
end

if not isRunByTool then
    -- Vehicle types must receive the specialization before they are finalized.
    Mission00.load = Utils.prependedFunction(Mission00.load, loadMission)
    Mission00.onStartMission = Utils.appendedFunction(Mission00.onStartMission, startMission)
    TypeManager.validateTypes = Utils.prependedFunction(TypeManager.validateTypes, installConditionSpecialization)
end
