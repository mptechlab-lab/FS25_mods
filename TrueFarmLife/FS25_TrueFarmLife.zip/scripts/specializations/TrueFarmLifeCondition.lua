-- True Farm Life - persistent mechanical condition, failures and workshop repairs.
-- Server-authoritative for multiplayer; the diagnostic UI remains local to each player.

TrueFarmLifeCondition = {}

TrueFarmLifeCondition.UPDATE_INTERVAL_MS = 1000
TrueFarmLifeCondition.ENGINE_WEAR_PER_HOUR = 0.00011
TrueFarmLifeCondition.BATTERY_WEAR_PER_HOUR = 0.00028
TrueFarmLifeCondition.TIRE_WEAR_PER_HOUR = 0.00038
TrueFarmLifeCondition.HYDRAULIC_WEAR_PER_HOUR = 0.00018
TrueFarmLifeCondition.SERVICE_WEAR_PER_HOUR = 0.00030

TrueFarmLifeCondition.FAULT_NONE = "none"
TrueFarmLifeCondition.FAULT_ENGINE = "engine"
TrueFarmLifeCondition.FAULT_BATTERY = "battery"
TrueFarmLifeCondition.FAULT_TIRE = "tire"
TrueFarmLifeCondition.FAULT_HYDRAULICS = "hydraulics"
TrueFarmLifeCondition.FAULT_IMPLEMENT = "implement"

TrueFarmLifeCondition.FAULT_TO_ID = {
    [TrueFarmLifeCondition.FAULT_NONE] = 0,
    [TrueFarmLifeCondition.FAULT_ENGINE] = 1,
    [TrueFarmLifeCondition.FAULT_BATTERY] = 2,
    [TrueFarmLifeCondition.FAULT_TIRE] = 3,
    [TrueFarmLifeCondition.FAULT_HYDRAULICS] = 4,
    [TrueFarmLifeCondition.FAULT_IMPLEMENT] = 5
}

TrueFarmLifeCondition.ID_TO_FAULT = {
    [0] = TrueFarmLifeCondition.FAULT_NONE,
    [1] = TrueFarmLifeCondition.FAULT_ENGINE,
    [2] = TrueFarmLifeCondition.FAULT_BATTERY,
    [3] = TrueFarmLifeCondition.FAULT_TIRE,
    [4] = TrueFarmLifeCondition.FAULT_HYDRAULICS,
    [5] = TrueFarmLifeCondition.FAULT_IMPLEMENT
}

local function clamp(value, minValue, maxValue)
    return math.max(minValue, math.min(maxValue, value))
end

local function getSpec(self)
    return self.spec_trueFarmLifeCondition
end

local function getText(key)
    return g_i18n:getText(key)
end

-- Some modded installs do not predefine InputAction before specialization registration.
-- Provide the custom action IDs locally so the action binding remains valid without
-- producing "undefined-global" warnings from static analysis.
InputAction = InputAction or {}
InputAction.TFL_TOGGLE_DIAGNOSTICS = InputAction.TFL_TOGGLE_DIAGNOSTICS or "TFL_TOGGLE_DIAGNOSTICS"
InputAction.TFL_CYCLE_PROFILE = InputAction.TFL_CYCLE_PROFILE or "TFL_CYCLE_PROFILE"
InputAction.TFL_INSPECT_VEHICLE = InputAction.TFL_INSPECT_VEHICLE or "TFL_INSPECT_VEHICLE"

function TrueFarmLifeCondition.prerequisitesPresent(specializations)
    return true
end

function TrueFarmLifeCondition.initSpecialization()
    local schema = Vehicle.xmlSchemaSavegame
    local baseKey = "vehicles.vehicle(?)." .. g_trueFarmLifeModName .. ".trueFarmLifeCondition"

    schema:register(XMLValueType.FLOAT, baseKey .. "#engine", "True Farm Life engine or moving-parts condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#battery", "True Farm Life battery or electrical condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#tires", "True Farm Life tires or rolling-parts condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#hydraulics", "True Farm Life hydraulic condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#operatingHours", "True Farm Life operating hours", 0)
    schema:register(XMLValueType.STRING, baseKey .. "#fault", "True Farm Life active fault", TrueFarmLifeCondition.FAULT_NONE)
    schema:register(XMLValueType.FLOAT, baseKey .. "#oilLevel", "Engine oil level", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#oilQuality", "Engine oil quality", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#coolant", "Coolant condition and level", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#airFilter", "Air filter condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#fuelFilter", "Fuel filter condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#oilFilter", "Oil filter condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#alternator", "Alternator condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#starter", "Starter motor condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#belts", "Accessory belt condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#drivetrain", "Clutch gearbox differential condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#pto", "PTO condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#brakes", "Brake condition", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#lights", "Lights, indicators and wipers condition", 1)
    for index = 1, 4 do
        schema:register(XMLValueType.FLOAT, baseKey .. "#tire" .. index, "Individual tire condition", 1)
        schema:register(XMLValueType.FLOAT, baseKey .. "#pressure" .. index, "Individual tire pressure", 1)
        schema:register(XMLValueType.FLOAT, baseKey .. "#tireTemperature" .. index, "Individual tire temperature", 20)
        schema:register(XMLValueType.FLOAT, baseKey .. "#tireImpactDamage" .. index, "Individual tire impact damage", 0)
    end
    schema:register(XMLValueType.STRING, baseKey .. "#history", "Recent True Farm Life service history", "")
    schema:register(XMLValueType.FLOAT, baseKey .. "#oilTemperature", "Calculated engine oil temperature", 20)
    schema:register(XMLValueType.FLOAT, baseKey .. "#oilPressure", "Calculated engine oil pressure", 1)
    schema:register(XMLValueType.FLOAT, baseKey .. "#oilLeak", "Progressive oil leak severity", 0)
    schema:register(XMLValueType.FLOAT, baseKey .. "#coolantLeak", "Progressive coolant leak severity", 0)
    schema:register(XMLValueType.FLOAT, baseKey .. "#nextServiceHours", "Next scheduled maintenance hour", 50)
    schema:register(XMLValueType.BOOL, baseKey .. "#limpMode", "Emergency power protection active", false)
end

function TrueFarmLifeCondition.registerOverwrittenFunctions(vehicleType)
    local specializations = vehicleType.specializations

    if SpecializationUtil.hasSpecialization(Motorized, specializations) then
        SpecializationUtil.registerOverwrittenFunction(vehicleType, "getCanMotorRun", TrueFarmLifeCondition.getCanMotorRun)
        SpecializationUtil.registerOverwrittenFunction(vehicleType, "getMotorNotAllowedWarning", TrueFarmLifeCondition.getMotorNotAllowedWarning)
    end

    if SpecializationUtil.hasSpecialization(Wearable, specializations) then
        SpecializationUtil.registerOverwrittenFunction(vehicleType, "getVehicleDamage", TrueFarmLifeCondition.getVehicleDamage)
        SpecializationUtil.registerOverwrittenFunction(vehicleType, "getRepairPrice", TrueFarmLifeCondition.getRepairPrice)
        SpecializationUtil.registerOverwrittenFunction(vehicleType, "repairVehicle", TrueFarmLifeCondition.repairVehicle)
    end

    if SpecializationUtil.hasSpecialization(TurnOnVehicle, specializations) then
        SpecializationUtil.registerOverwrittenFunction(vehicleType, "getCanBeTurnedOn", TrueFarmLifeCondition.getCanBeTurnedOn)
        SpecializationUtil.registerOverwrittenFunction(vehicleType, "getTurnedOnNotAllowedWarning", TrueFarmLifeCondition.getTurnedOnNotAllowedWarning)
    end
end

-- Helper methods are invoked through the vehicle instance (self:method()).
-- FS25 only exposes them on a vehicle type when explicitly registered here.
function TrueFarmLifeCondition.registerFunctions(vehicleType)
    local functions = {
        "writeConditionState", "readConditionState", "getOperatingHourDelta",
        "getProfile", "getIsOperating", "getWorkloadMultiplier", "getWeakestComponent",
        "getEngineTemperature", "getServiceWeakness", "addHistory", "setFault",
        "tryTriggerFailure", "getPartsRepairPrice", "getComponentLabel", "getConditionColor"
    }
    for _, name in ipairs(functions) do
        SpecializationUtil.registerFunction(vehicleType, name, TrueFarmLifeCondition[name])
    end
end

function TrueFarmLifeCondition.registerEventListeners(vehicleType)
    SpecializationUtil.registerEventListener(vehicleType, "onLoad", TrueFarmLifeCondition)
    SpecializationUtil.registerEventListener(vehicleType, "onPostLoad", TrueFarmLifeCondition)
    SpecializationUtil.registerEventListener(vehicleType, "onUpdateTick", TrueFarmLifeCondition)
    SpecializationUtil.registerEventListener(vehicleType, "onDraw", TrueFarmLifeCondition)
    SpecializationUtil.registerEventListener(vehicleType, "onRegisterActionEvents", TrueFarmLifeCondition)
    SpecializationUtil.registerEventListener(vehicleType, "onReadStream", TrueFarmLifeCondition)
    SpecializationUtil.registerEventListener(vehicleType, "onWriteStream", TrueFarmLifeCondition)
    SpecializationUtil.registerEventListener(vehicleType, "onReadUpdateStream", TrueFarmLifeCondition)
    SpecializationUtil.registerEventListener(vehicleType, "onWriteUpdateStream", TrueFarmLifeCondition)
end

function TrueFarmLifeCondition:onLoad(savegame)
    local dynamicSpecKey = "spec_" .. g_trueFarmLifeModName .. ".trueFarmLifeCondition"
    self.spec_trueFarmLifeCondition = self[dynamicSpecKey]

    local spec = getSpec(self)
    spec.hasMotor = self.spec_motorized ~= nil
    spec.hasWearable = self.spec_wearable ~= nil
    spec.engine = 1
    spec.battery = 1
    spec.tires = 1
    spec.hydraulics = 1
    spec.oilLevel, spec.oilQuality, spec.coolant = 1, 1, 1
    spec.airFilter, spec.fuelFilter, spec.oilFilter = 1, 1, 1
    spec.alternator, spec.starter, spec.belts = 1, 1, 1
    spec.drivetrain, spec.pto, spec.brakes, spec.lights = 1, 1, 1, 1
    spec.tireCondition = {1, 1, 1, 1}
    spec.tirePressure = {1, 1, 1, 1}
    spec.tireTemperature, spec.tireImpactDamage = {20, 20, 20, 20}, {0, 0, 0, 0}
    spec.oilTemperature, spec.oilPressure, spec.oilLeak, spec.coolantLeak = 20, 1, 0, 0
    spec.nextServiceHours = 50
    spec.limpMode = false
    spec.history = ""
    spec.operatingHours = 0
    spec.fault = TrueFarmLifeCondition.FAULT_NONE
    spec.oilLeak, spec.coolantLeak = 0, 0
    spec.oilTemperature, spec.oilPressure = 20, 1
    spec.updateTimer = 0
    spec.previousSpeed = 0
    spec.showDiagnostics = false
    spec.lastDiagnosticsToggle = -1000
    spec.actionEvents = {}
    spec.dirtyFlag = self:getNextDirtyFlag()
end

function TrueFarmLifeCondition:onPostLoad(savegame)
    if savegame == nil or savegame.resetVehicles then
        return
    end

    local spec = getSpec(self)
    local key = savegame.key .. "." .. g_trueFarmLifeModName .. ".trueFarmLifeCondition"
    spec.engine = clamp(savegame.xmlFile:getValue(key .. "#engine", 1), 0, 1)
    spec.battery = clamp(savegame.xmlFile:getValue(key .. "#battery", 1), 0, 1)
    spec.tires = clamp(savegame.xmlFile:getValue(key .. "#tires", 1), 0, 1)
    spec.hydraulics = clamp(savegame.xmlFile:getValue(key .. "#hydraulics", 1), 0, 1)
    spec.operatingHours = math.max(savegame.xmlFile:getValue(key .. "#operatingHours", 0), 0)
    spec.fault = TrueFarmLifeCondition.ID_TO_FAULT[TrueFarmLifeCondition.FAULT_TO_ID[savegame.xmlFile:getValue(key .. "#fault", TrueFarmLifeCondition.FAULT_NONE)]] or TrueFarmLifeCondition.FAULT_NONE
    local values = {"oilLevel", "oilQuality", "coolant", "airFilter", "fuelFilter", "oilFilter", "alternator", "starter", "belts", "drivetrain", "pto", "brakes", "lights"}
    for _, name in ipairs(values) do spec[name] = clamp(savegame.xmlFile:getValue(key .. "#" .. name, 1), 0, 1) end
    for index = 1, 4 do
        spec.tireCondition[index] = clamp(savegame.xmlFile:getValue(key .. "#tire" .. index, spec.tires), 0, 1)
        spec.tirePressure[index] = clamp(savegame.xmlFile:getValue(key .. "#pressure" .. index, 1), 0.2, 1.3)
        spec.tireTemperature[index] = savegame.xmlFile:getValue(key .. "#tireTemperature" .. index, 20)
        spec.tireImpactDamage[index] = clamp(savegame.xmlFile:getValue(key .. "#tireImpactDamage" .. index, 0), 0, 1)
    end
    spec.history = savegame.xmlFile:getValue(key .. "#history", "")
    spec.oilTemperature = savegame.xmlFile:getValue(key .. "#oilTemperature", 20)
    spec.oilPressure = clamp(savegame.xmlFile:getValue(key .. "#oilPressure", 1), 0, 1)
    spec.oilLeak = clamp(savegame.xmlFile:getValue(key .. "#oilLeak", 0), 0, 1)
    spec.coolantLeak = clamp(savegame.xmlFile:getValue(key .. "#coolantLeak", 0), 0, 1)
    spec.nextServiceHours = math.max(savegame.xmlFile:getValue(key .. "#nextServiceHours", 50), 50)
    spec.limpMode = savegame.xmlFile:getValue(key .. "#limpMode", false)
end

function TrueFarmLifeCondition:saveToXMLFile(xmlFile, key, usedModNames)
    local spec = getSpec(self)
    xmlFile:setValue(key .. "#engine", spec.engine)
    xmlFile:setValue(key .. "#battery", spec.battery)
    xmlFile:setValue(key .. "#tires", spec.tires)
    xmlFile:setValue(key .. "#hydraulics", spec.hydraulics)
    xmlFile:setValue(key .. "#operatingHours", spec.operatingHours)
    xmlFile:setValue(key .. "#fault", spec.fault)
    local values = {"oilLevel", "oilQuality", "coolant", "airFilter", "fuelFilter", "oilFilter", "alternator", "starter", "belts", "drivetrain", "pto", "brakes", "lights"}
    for _, name in ipairs(values) do xmlFile:setValue(key .. "#" .. name, spec[name]) end
    for index = 1, 4 do
        xmlFile:setValue(key .. "#tire" .. index, spec.tireCondition[index])
        xmlFile:setValue(key .. "#pressure" .. index, spec.tirePressure[index])
        xmlFile:setValue(key .. "#tireTemperature" .. index, spec.tireTemperature[index])
        xmlFile:setValue(key .. "#tireImpactDamage" .. index, spec.tireImpactDamage[index])
    end
    xmlFile:setValue(key .. "#history", spec.history)
    xmlFile:setValue(key .. "#oilTemperature", spec.oilTemperature)
    xmlFile:setValue(key .. "#oilPressure", spec.oilPressure)
    xmlFile:setValue(key .. "#oilLeak", spec.oilLeak)
    xmlFile:setValue(key .. "#coolantLeak", spec.coolantLeak)
    xmlFile:setValue(key .. "#nextServiceHours", spec.nextServiceHours)
    xmlFile:setValue(key .. "#limpMode", spec.limpMode)
end

function TrueFarmLifeCondition:writeConditionState(streamId)
    local spec = getSpec(self)
    streamWriteFloat32(streamId, spec.engine)
    streamWriteFloat32(streamId, spec.battery)
    streamWriteFloat32(streamId, spec.tires)
    streamWriteFloat32(streamId, spec.hydraulics)
    streamWriteFloat32(streamId, spec.operatingHours)
    streamWriteUIntN(streamId, TrueFarmLifeCondition.FAULT_TO_ID[spec.fault] or 0, 3)
    local values = {"oilLevel", "oilQuality", "coolant", "airFilter", "fuelFilter", "oilFilter", "alternator", "starter", "belts", "drivetrain", "pto", "brakes", "lights"}
    for _, name in ipairs(values) do streamWriteFloat32(streamId, spec[name]) end
    for index = 1, 4 do
        streamWriteFloat32(streamId, spec.tireCondition[index])
        streamWriteFloat32(streamId, spec.tirePressure[index])
        streamWriteFloat32(streamId, spec.tireTemperature[index])
        streamWriteFloat32(streamId, spec.tireImpactDamage[index])
    end
    streamWriteFloat32(streamId, spec.nextServiceHours)
end

function TrueFarmLifeCondition:readConditionState(streamId)
    local spec = getSpec(self)
    spec.engine = clamp(streamReadFloat32(streamId), 0, 1)
    spec.battery = clamp(streamReadFloat32(streamId), 0, 1)
    spec.tires = clamp(streamReadFloat32(streamId), 0, 1)
    spec.hydraulics = clamp(streamReadFloat32(streamId), 0, 1)
    spec.operatingHours = math.max(streamReadFloat32(streamId), 0)
    spec.fault = TrueFarmLifeCondition.ID_TO_FAULT[streamReadUIntN(streamId, 3)] or TrueFarmLifeCondition.FAULT_NONE
    local values = {"oilLevel", "oilQuality", "coolant", "airFilter", "fuelFilter", "oilFilter", "alternator", "starter", "belts", "drivetrain", "pto", "brakes", "lights"}
    for _, name in ipairs(values) do spec[name] = clamp(streamReadFloat32(streamId), 0, 1) end
    for index = 1, 4 do
        spec.tireCondition[index] = clamp(streamReadFloat32(streamId), 0, 1)
        spec.tirePressure[index] = clamp(streamReadFloat32(streamId), 0.2, 1.3)
        spec.tireTemperature[index] = streamReadFloat32(streamId)
        spec.tireImpactDamage[index] = clamp(streamReadFloat32(streamId), 0, 1)
    end
    spec.nextServiceHours = streamReadFloat32(streamId)
end

function TrueFarmLifeCondition:onWriteStream(streamId, connection)
    self:writeConditionState(streamId)
end

function TrueFarmLifeCondition:onReadStream(streamId, connection)
    self:readConditionState(streamId)
end

function TrueFarmLifeCondition:onWriteUpdateStream(streamId, connection, dirtyMask)
    local spec = getSpec(self)
    if not connection:getIsServer() then
        if streamWriteBool(streamId, bit32.band(dirtyMask, spec.dirtyFlag) ~= 0) then
            self:writeConditionState(streamId)
        end
    end
end

function TrueFarmLifeCondition:onReadUpdateStream(streamId, timestamp, connection)
    if streamReadBool(streamId) then
        self:readConditionState(streamId)
    end
end

function TrueFarmLifeCondition:getOperatingHourDelta(milliseconds)
    local timeScale = 1
    if g_currentMission ~= nil and g_currentMission.missionInfo ~= nil and g_currentMission.missionInfo.timeScale ~= nil then
        timeScale = g_currentMission.missionInfo.timeScale
    end

    -- An in-game hour at the selected time scale is one simulated service hour.
    return milliseconds * math.max(timeScale, 1) / 3600000
end

function TrueFarmLifeCondition:getProfile()
    return TrueFarmLifeProfiles.getActive()
end

function TrueFarmLifeCondition:addHistory(entry)
    local spec = getSpec(self)
    local stamp = string.format("%.0fh", spec.operatingHours)
    local line = stamp .. " " .. entry
    spec.history = spec.history == "" and line or (line .. " | " .. spec.history)
    -- Keep the savegame value small and readable; the newest six events are retained.
    local count = 0
    for _ in string.gmatch(spec.history, "|") do count = count + 1 end
    while count >= 6 do
        spec.history = string.gsub(spec.history, "[^|]+|%s*", "", 1)
        count = count - 1
    end
end

function TrueFarmLifeCondition:getEngineTemperature()
    local motorTemperature = self.spec_motorized ~= nil and self.spec_motorized.motorTemperature or nil
    if motorTemperature ~= nil and motorTemperature.value ~= nil then return motorTemperature.value end
    return self:getIsOperating() and 85 or 20
end

function TrueFarmLifeCondition:getServiceWeakness()
    local spec = getSpec(self)
    local weakestName, weakestValue = "engine", spec.engine
    local values = {"oilLevel", "oilQuality", "coolant", "airFilter", "fuelFilter", "oilFilter", "alternator", "starter", "belts", "drivetrain", "pto", "brakes", "lights", "hydraulics"}
    for _, name in ipairs(values) do
        if spec[name] < weakestValue then weakestName, weakestValue = name, spec[name] end
    end
    for index = 1, 4 do
        local tireValue = math.min(spec.tireCondition[index], spec.tirePressure[index])
        if tireValue < weakestValue then weakestName, weakestValue = "tire", tireValue end
    end
    return weakestName, weakestValue
end

function TrueFarmLifeCondition:getIsOperating()
    local spec = getSpec(self)
    if spec.hasMotor and self.getIsMotorStarted ~= nil then
        return self:getIsMotorStarted()
    end

    return self.getIsTurnedOn ~= nil and self:getIsTurnedOn()
end

function TrueFarmLifeCondition:getWorkloadMultiplier()
    local profile = TrueFarmLifeCondition.getProfile(self)
    local multiplier = 1
    if self.isOnField then
        multiplier = multiplier + 0.20
    end
    if self.getIsTurnedOn ~= nil and self:getIsTurnedOn() then
        multiplier = multiplier + 0.35
    end
    if self.getDirtAmount ~= nil and self:getDirtAmount() > 0.70 then
        multiplier = multiplier + 0.15
    end

    local weather = g_currentMission ~= nil and g_currentMission.environment ~= nil and g_currentMission.environment.weather or nil
    if self.isOnField and weather ~= nil and weather:getRainFallScale() > 0.10 then
        multiplier = multiplier + weather:getRainFallScale() * profile.rainWorkloadMultiplier
    end
    if self.isOnField and TrueFarmLifeWorld ~= nil and TrueFarmLifeWorld.getSoilWetness ~= nil then
        local moisture, compaction = TrueFarmLifeWorld.getSoilConditionAtVehicle(self)
        multiplier = multiplier + moisture * 0.35 + compaction * 0.25
    end

    local motorTemperature = self.spec_motorized ~= nil and self.spec_motorized.motorTemperature or nil
    if motorTemperature ~= nil and motorTemperature.valueMax ~= nil and motorTemperature.value ~= nil then
        if motorTemperature.value > motorTemperature.valueMax * 0.93 then
            multiplier = multiplier + 0.65
        end
    end

    return multiplier
end

function TrueFarmLifeCondition:getWeakestComponent()
    local spec = getSpec(self)
    local component = "engine"
    local condition = spec.engine

    if spec.battery < condition then
        component = "battery"
        condition = spec.battery
    end
    if spec.tires < condition then
        component = "tires"
        condition = spec.tires
    end
    if spec.hydraulics < condition then
        component = "hydraulics"
        condition = spec.hydraulics
    end

    local serviceComponent, serviceCondition = self:getServiceWeakness()
    if serviceCondition < condition then
        component, condition = serviceComponent, serviceCondition
    end

    return component, condition
end

function TrueFarmLifeCondition:setFault(fault)
    local spec = getSpec(self)
    if spec.fault ~= TrueFarmLifeCondition.FAULT_NONE then
        return
    end

    spec.fault = fault
    if fault == TrueFarmLifeCondition.FAULT_ENGINE and self.getIsMotorStarted ~= nil and self:getIsMotorStarted() then
        self:stopMotor()
    end

    if self.isServer then
        self:raiseDirtyFlags(spec.dirtyFlag)
    end

    if self.isClient and self.getIsActiveForInput ~= nil and self:getIsActiveForInput(true) then
        g_currentMission:showBlinkingWarning(getText("tfl_fault_" .. fault), 4500)
    end
    if TrueFarmLife.core ~= nil then
        TrueFarmLife.core:recordVehicleEvent(self, "fault", getText("tfl_fault_" .. fault))
    end
end

function TrueFarmLifeCondition:tryTriggerFailure(hours, workload)
    local spec = getSpec(self)
    if spec.fault ~= TrueFarmLifeCondition.FAULT_NONE then
        return
    end

    local component, condition = self:getWeakestComponent()
    if condition > 0.40 then
        return
    end

    local probability = math.pow(1 - condition, 3) * 0.04 * hours * workload * self:getProfile().failureMultiplier
    if math.random() >= probability then
        return
    end

    if not spec.hasMotor then
        self:setFault(TrueFarmLifeCondition.FAULT_IMPLEMENT)
    elseif component == "engine" then
        self:setFault(TrueFarmLifeCondition.FAULT_ENGINE)
    elseif component == "battery" or component == "alternator" or component == "starter" or component == "lights" then
        self:setFault(TrueFarmLifeCondition.FAULT_BATTERY)
    elseif component == "tires" or component == "tire" then
        self:setFault(TrueFarmLifeCondition.FAULT_TIRE)
    elseif component == "pto" or component == "hydraulics" then
        self:setFault(TrueFarmLifeCondition.FAULT_HYDRAULICS)
    else
        self:setFault(TrueFarmLifeCondition.FAULT_ENGINE)
    end
end

function TrueFarmLifeCondition:onUpdateTick(dt, isActiveForInput, isActiveForInputIgnoreSelection, isSelected)
    if not self.isServer then
        return
    end

    local spec = getSpec(self)
    spec.updateTimer = spec.updateTimer + dt
    if spec.updateTimer < TrueFarmLifeCondition.UPDATE_INTERVAL_MS then
        return
    end

    local elapsed = spec.updateTimer
    spec.updateTimer = 0
    if not self:getIsOperating() then
        return
    end

    local hours = TrueFarmLifeCondition.getOperatingHourDelta(self, elapsed)
    local workload = TrueFarmLifeCondition.getWorkloadMultiplier(self)
    local profile = TrueFarmLifeCondition.getProfile(self)
    spec.operatingHours = spec.operatingHours + hours
    if self.isOnField and TrueFarmLifeWorld ~= nil and TrueFarmLifeWorld.recordFieldPass ~= nil then
        TrueFarmLifeWorld.recordFieldPass(self, workload)
    end
    if spec.operatingHours > spec.nextServiceHours then
        workload = workload + math.min(0.80, (spec.operatingHours - spec.nextServiceHours) / 250)
    end
    spec.engine = clamp(spec.engine - TrueFarmLifeCondition.ENGINE_WEAR_PER_HOUR * hours * workload * profile.wearMultiplier, 0, 1)
    spec.battery = clamp(spec.battery - TrueFarmLifeCondition.BATTERY_WEAR_PER_HOUR * hours * (0.35 + workload * 0.20) * profile.wearMultiplier, 0, 1)
    spec.tires = clamp(spec.tires - TrueFarmLifeCondition.TIRE_WEAR_PER_HOUR * hours * (self.isOnField and workload or 0.45) * profile.wearMultiplier, 0, 1)
    spec.hydraulics = clamp(spec.hydraulics - TrueFarmLifeCondition.HYDRAULIC_WEAR_PER_HOUR * hours * workload * profile.wearMultiplier, 0, 1)

    -- Advanced service parts age independently. Temperature, dirt, field work and rain
    -- all feed the same workload chain instead of producing disconnected random faults.
    local serviceWear = TrueFarmLifeCondition.SERVICE_WEAR_PER_HOUR * hours * workload * profile.wearMultiplier
    local temperature = TrueFarmLifeCondition.getEngineTemperature(self)
    local heatFactor = temperature > 96 and (1 + (temperature - 96) / 30) or 1
    spec.oilTemperature = clamp(spec.oilTemperature + (temperature - spec.oilTemperature) * 0.14, -20, 165)
    spec.oilPressure = clamp(spec.oilLevel * spec.oilQuality * (1 - spec.oilLeak * 0.75) * (spec.oilTemperature > 145 and 0.50 or 1), 0, 1)
    spec.limpMode = spec.oilPressure < 0.22 or spec.coolant < 0.18
    if (spec.oilFilter < 0.25 or spec.oilQuality < 0.20) and math.random() < serviceWear * heatFactor * 8 then spec.oilLeak = clamp(spec.oilLeak + 0.10, 0, 1) end
    if spec.belts < 0.28 and math.random() < serviceWear * heatFactor * 8 then spec.coolantLeak = clamp(spec.coolantLeak + 0.10, 0, 1) end
    spec.oilQuality = clamp(spec.oilQuality - serviceWear * heatFactor, 0, 1)
    spec.oilLevel = clamp(spec.oilLevel - serviceWear * (0.22 + spec.oilLeak * 7) * heatFactor, 0, 1)
    spec.coolant = clamp(spec.coolant - serviceWear * (0.14 + spec.coolantLeak * 7) * heatFactor, 0, 1)
    spec.airFilter = clamp(spec.airFilter - serviceWear * (self.getDirtAmount ~= nil and (0.6 + self:getDirtAmount()) or 0.7), 0, 1)
    spec.fuelFilter = clamp(spec.fuelFilter - serviceWear * 0.50, 0, 1)
    spec.oilFilter = clamp(spec.oilFilter - serviceWear * 0.75 * heatFactor, 0, 1)
    spec.alternator = clamp(spec.alternator - serviceWear * 0.25, 0, 1)
    spec.starter = clamp(spec.starter - serviceWear * 0.12, 0, 1)
    spec.belts = clamp(spec.belts - serviceWear * 0.35 * heatFactor, 0, 1)
    spec.drivetrain = clamp(spec.drivetrain - serviceWear * (self.isOnField and 0.85 or 0.35), 0, 1)
    spec.pto = clamp(spec.pto - serviceWear * (self.getIsTurnedOn ~= nil and self:getIsTurnedOn() and 0.9 or 0.25), 0, 1)
    spec.brakes = clamp(spec.brakes - serviceWear * 0.30, 0, 1)
    spec.lights = clamp(spec.lights - serviceWear * 0.08, 0, 1)
    local speed = self.getLastSpeed ~= nil and self:getLastSpeed() or 0
    -- A sharp speed collapse at road speed is treated as an impact. It intentionally
    -- does not replace base physics; it adds persistent mechanical consequences.
    if spec.previousSpeed > 18 and speed < spec.previousSpeed * 0.25 then
        local severity = clamp((spec.previousSpeed - speed) / 45, 0.10, 0.65)
        for index = 1, 4 do
            spec.tireImpactDamage[index] = clamp(spec.tireImpactDamage[index] + severity * 0.35, 0, 1)
            spec.tireCondition[index] = clamp(spec.tireCondition[index] - severity * 0.18, 0, 1)
            spec.tirePressure[index] = clamp(spec.tirePressure[index] - severity * 0.10, 0.2, 1.3)
        end
        spec.coolantLeak = clamp(spec.coolantLeak + severity * 0.18, 0, 1)
        if TrueFarmLife.core ~= nil then TrueFarmLife.core:recordVehicleEvent(self, "impact", "Impact detected: inspect tyres and cooling") end
    end
    spec.previousSpeed = speed
    local tireTotal = 0
    for index = 1, 4 do
        local pressurePenalty = 1 + math.abs(spec.tirePressure[index] - 1) * 1.8
        spec.tireTemperature[index] = clamp(spec.tireTemperature[index] + (20 + speed * 0.22 * pressurePenalty - spec.tireTemperature[index]) * 0.12, -20, 155)
        if spec.tireTemperature[index] > 125 then spec.tireImpactDamage[index] = clamp(spec.tireImpactDamage[index] + serviceWear * 10, 0, 1) end
        spec.tireCondition[index] = clamp(spec.tireCondition[index] - serviceWear * pressurePenalty * (self.isOnField and 0.95 or 0.35), 0, 1)
        -- A slow pressure leak becomes meaningful before it becomes a puncture.
        if spec.tireCondition[index] < 0.35 then spec.tirePressure[index] = clamp(spec.tirePressure[index] - serviceWear * 0.9, 0.2, 1.3) end
        tireTotal = tireTotal + math.min(spec.tireCondition[index], spec.tirePressure[index]) * (1 - spec.tireImpactDamage[index] * 0.50)
    end
    spec.tires = tireTotal / 4

    self:tryTriggerFailure(hours, workload)
    self:raiseDirtyFlags(spec.dirtyFlag)
end

function TrueFarmLifeCondition:getCanMotorRun(superFunc)
    local spec = getSpec(self)
    local fault = spec.fault
    if fault == TrueFarmLifeCondition.FAULT_ENGINE or fault == TrueFarmLifeCondition.FAULT_BATTERY then
        return false
    end
    local engineTemperature = 20

if self.getEngineTemperature ~= nil then
    engineTemperature = self:getEngineTemperature()
end

if engineTemperature < 2 and (spec.battery < 0.62 or spec.fuelFilter < 0.35) then
    spec.startWarning = "tfl_start_cold"
    return false
end
   local engineTemperature = TrueFarmLifeCondition.getEngineTemperature(self)

if engineTemperature < 2 and (spec.battery < 0.62 or spec.fuelFilter < 0.35) then
    spec.startWarning = "tfl_start_cold"
    return false
end
    spec.startWarning = nil

    return superFunc(self)
end

function TrueFarmLifeCondition:getMotorNotAllowedWarning(superFunc)
    local spec = getSpec(self)
    local fault = spec.fault
    if fault == TrueFarmLifeCondition.FAULT_ENGINE or fault == TrueFarmLifeCondition.FAULT_BATTERY then
        return getText("tfl_fault_" .. fault)
    end
    if spec.startWarning ~= nil then return getText(spec.startWarning) end

    return superFunc(self)
end

function TrueFarmLifeCondition:getCanBeTurnedOn(superFunc, isTurnedOn)
    local fault = getSpec(self).fault
    if not isTurnedOn and (fault == TrueFarmLifeCondition.FAULT_HYDRAULICS or fault == TrueFarmLifeCondition.FAULT_IMPLEMENT) then
        return false
    end

    local weather = g_currentMission ~= nil and g_currentMission.environment ~= nil and g_currentMission.environment.weather or nil
    if not isTurnedOn and self.isOnField and self:getProfile().blockWetFieldWork and weather ~= nil and weather:getRainFallScale() > 0.20 then
        return false
    end

    return superFunc(self, isTurnedOn)
end

function TrueFarmLifeCondition:getTurnedOnNotAllowedWarning(superFunc)
    local fault = getSpec(self).fault
    if fault == TrueFarmLifeCondition.FAULT_HYDRAULICS or fault == TrueFarmLifeCondition.FAULT_IMPLEMENT then
        return getText("tfl_fault_" .. fault)
    end

    local weather = g_currentMission ~= nil and g_currentMission.environment ~= nil and g_currentMission.environment.weather or nil
    if self.isOnField and self:getProfile().blockWetFieldWork and weather ~= nil and weather:getRainFallScale() > 0.20 then
        return getText("tfl_weather_tooWet")
    end

    return superFunc(self)
end

function TrueFarmLifeCondition:getVehicleDamage(superFunc)
    local damage = superFunc(self)
    local spec = getSpec(self)
    local fault = spec.fault
    if fault == TrueFarmLifeCondition.FAULT_TIRE then
        damage = damage + 0.25
    elseif fault == TrueFarmLifeCondition.FAULT_ENGINE then
        damage = damage + 0.35
    elseif fault == TrueFarmLifeCondition.FAULT_HYDRAULICS or fault == TrueFarmLifeCondition.FAULT_IMPLEMENT then
        damage = damage + 0.15
    end
    local impactDamage = 0
    for index = 1, 4 do impactDamage = impactDamage + spec.tireImpactDamage[index] end
    damage = damage + impactDamage / 4 * 0.18
    if spec.limpMode then damage = damage + 0.22 end

    local weather = g_currentMission ~= nil and g_currentMission.environment ~= nil and g_currentMission.environment.weather or nil
    if self.isOnField and weather ~= nil and weather:getRainFallScale() > 0.10 then
        -- Uses the game's existing performance-loss path instead of rewriting wheel physics.
        damage = damage + weather:getRainFallScale() * self:getProfile().wetTractionPenalty
    end
    if self.isOnField and TrueFarmLifeWorld ~= nil and TrueFarmLifeWorld.getSoilWetness ~= nil then
        local moisture, compaction = TrueFarmLifeWorld.getSoilConditionAtVehicle(self)
        damage = damage + (moisture + compaction * 0.8) * self:getProfile().wetTractionPenalty
    end

    return math.min(damage, 1)
end

function TrueFarmLifeCondition:getPartsRepairPrice()
    local spec = getSpec(self)
    local vehiclePrice = self.getPrice ~= nil and self:getPrice() or 10000
    local partsFactor = (1 - spec.engine) * 0.035 + (1 - spec.battery) * 0.003 + (1 - spec.tires) * 0.012 + (1 - spec.hydraulics) * 0.020
    return vehiclePrice * partsFactor * self:getProfile().repairCostMultiplier
end

function TrueFarmLifeCondition:getRepairPrice(superFunc)
    return superFunc(self) + self:getPartsRepairPrice()
end

function TrueFarmLifeCondition:repairVehicle(superFunc)
    superFunc(self)

    -- The base-game repair event is executed on both peers; component state belongs to the server.
    if not self.isServer then
        return
    end

    local spec = getSpec(self)
    local fault = spec.fault
    if fault == TrueFarmLifeCondition.FAULT_ENGINE or fault == TrueFarmLifeCondition.FAULT_IMPLEMENT then
        spec.engine = 1
    else
        spec.engine = math.min(1, spec.engine + 0.22)
    end

    if fault == TrueFarmLifeCondition.FAULT_BATTERY then
        spec.battery = 1
    else
        spec.battery = math.min(1, spec.battery + 0.22)
    end

    if fault == TrueFarmLifeCondition.FAULT_TIRE then
        spec.tires = 1
    else
        spec.tires = math.min(1, spec.tires + 0.18)
    end

    if fault == TrueFarmLifeCondition.FAULT_HYDRAULICS then
        spec.hydraulics = 1
    else
        spec.hydraulics = math.min(1, spec.hydraulics + 0.20)
    end

    local serviceParts = {"oilLevel", "oilQuality", "coolant", "airFilter", "fuelFilter", "oilFilter", "alternator", "starter", "belts", "drivetrain", "pto", "brakes", "lights"}
    for _, name in ipairs(serviceParts) do
        spec[name] = math.min(1, spec[name] + 0.40)
    end
    for index = 1, 4 do
        spec.tireCondition[index] = math.min(1, spec.tireCondition[index] + 0.30)
        spec.tirePressure[index] = 1
        spec.tireImpactDamage[index] = math.max(0, spec.tireImpactDamage[index] - 0.50)
        spec.tireTemperature[index] = 20
    end
    self:addHistory(getText("tfl_history_service"))
    spec.oilLeak, spec.coolantLeak = 0, 0
    spec.oilTemperature, spec.oilPressure = 20, 1
    spec.nextServiceHours = (math.floor(spec.operatingHours / 250) + 1) * 250
    spec.limpMode = false

    spec.fault = TrueFarmLifeCondition.FAULT_NONE
    if TrueFarmLife.core ~= nil then
        TrueFarmLife.core:recordVehicleEvent(self, "service", getText("tfl_history_service"))
    end
    if self.isServer then
        self:raiseDirtyFlags(spec.dirtyFlag)
    end
end

function TrueFarmLifeCondition.actionEventToggleDiagnostics(self, actionName, inputValue, callbackState, isAnalog)
    local spec = getSpec(self)
    -- Keyboard actions may deliver both press/release or key-repeat callbacks.
    -- Toggle only on the positive edge and ignore repeats for a short interval.
    if inputValue ~= nil and inputValue <= 0 then
        return
    end
    if g_time - spec.lastDiagnosticsToggle < 250 then
        return
    end
    spec.lastDiagnosticsToggle = g_time
    spec.showDiagnostics = not spec.showDiagnostics
end

function TrueFarmLifeCondition.actionEventCycleProfile(self, actionName, inputValue, callbackState, isAnalog)
    if not self.isServer then
        return
    end

    local profileName = TrueFarmLifeProfiles.cycle()
    if self.isClient then
        g_currentMission:showBlinkingWarning(string.format(getText("tfl_profile_changed"), getText("tfl_profile_" .. profileName)), 2500)
    end
end

function TrueFarmLifeCondition.actionEventInspectVehicle(self, actionName, inputValue, callbackState, isAnalog)
    local critical, value = self:getServiceWeakness()
    local status = value < 0.40 and getText("tfl_inspection_attention") or getText("tfl_inspection_ok")
    local message = string.format(getText("tfl_inspection_result"), status, getText("tfl_component_" .. critical), math.floor(value * 100 + 0.5))
    g_currentMission:showBlinkingWarning(message, 4500)
    if TrueFarmLife.core ~= nil then
        TrueFarmLife.core:recordVehicleEvent(self, "inspection", getText("tfl_history_inspection"))
    end
end

function TrueFarmLifeCondition:onRegisterActionEvents(isActiveForInput, isActiveForInputIgnoreSelection)
    if not self.isClient then
        return
    end

    local spec = getSpec(self)
    self:clearActionEventsTable(spec.actionEvents)
    if isActiveForInputIgnoreSelection then
        local _, actionEventId = self:addActionEvent(
            spec.actionEvents,
            InputAction.TFL_TOGGLE_DIAGNOSTICS,
            self,
            TrueFarmLifeCondition.actionEventToggleDiagnostics,
            false,
            true,
            false,
            true,
            nil
        )
        g_inputBinding:setActionEventText(actionEventId, getText("tfl_action_toggleDiagnostics"))

        _, actionEventId = self:addActionEvent(
            spec.actionEvents,
            InputAction.TFL_CYCLE_PROFILE,
            self,
            TrueFarmLifeCondition.actionEventCycleProfile,
            false,
            true,
            false,
            true,
            nil
        )
        g_inputBinding:setActionEventText(actionEventId, string.format(getText("tfl_action_cycleProfile"), getText("tfl_profile_" .. TrueFarmLifeProfiles.getName())))

        _, actionEventId = self:addActionEvent(
            spec.actionEvents, InputAction.TFL_INSPECT_VEHICLE, self,
            TrueFarmLifeCondition.actionEventInspectVehicle, false, true, false, true, nil
        )
        g_inputBinding:setActionEventText(actionEventId, getText("tfl_action_inspectVehicle"))
    end
end

function TrueFarmLifeCondition:getComponentLabel(component)
    local spec = getSpec(self)
    if spec.hasMotor then
        return getText("tfl_component_" .. component)
    end

    local implementLabels = {
        engine = "tfl_component_workParts",
        battery = "tfl_component_electrics",
        tires = "tfl_component_rollingParts",
        hydraulics = "tfl_component_hydraulics"
    }
    return getText(implementLabels[component])
end

function TrueFarmLifeCondition:getConditionColor(condition)
    if condition > 0.70 then
        return 0.35, 0.90, 0.40, 1
    elseif condition > 0.40 then
        return 1.0, 0.77, 0.20, 1
    end
    return 1.0, 0.28, 0.24, 1
end

function TrueFarmLifeCondition:onDraw()
    if not self.isClient then
        return
    end

    local spec = getSpec(self)
    if not spec.showDiagnostics or self.getIsActiveForInput == nil or not self:getIsActiveForInput(true) then
        return
    end

    local x, y, width, height = 0.020, 0.635, 0.330, 0.315
    drawFilledRectRound(x, y, width, height, 0.008, 0.02, 0.02, 0.02, 0.86)
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextBold(true)
    setTextColor(0.95, 0.95, 0.95, 1)
    renderText(x + 0.012, y + height - 0.030, 0.018, getText("tfl_hud_title"))

    setTextBold(false)
    local lineY = y + height - 0.057
    local components = {"engine", "battery", "tires", "hydraulics"}
    for _, component in ipairs(components) do
        local condition = spec[component]
        local red, green, blue, alpha = self:getConditionColor(condition)
        setTextColor(red, green, blue, alpha)
        renderText(x + 0.012, lineY, 0.014, string.format("%s: %d%%", self:getComponentLabel(component), math.floor(condition * 100 + 0.5)))
        lineY = lineY - 0.027
    end

    local tireWorst = 1
    for index = 1, 4 do tireWorst = math.min(tireWorst, spec.tireCondition[index], spec.tirePressure[index]) end
    setTextColor(0.88, 0.88, 0.88, 1)
renderText(x + 0.012, lineY, 0.013, string.format("Temp. motore: %.0f C", TrueFarmLifeCondition.getEngineTemperature(self)))    lineY = lineY - 0.023
    renderText(x + 0.012, lineY, 0.013, string.format("Olio / refrigerante: %d%% / %d%%", math.floor(spec.oilLevel * 100 + 0.5), math.floor(spec.coolant * 100 + 0.5)))
    lineY = lineY - 0.023
    renderText(x + 0.012, lineY, 0.013, string.format("Pressione/gomma peggiore: %d%%", math.floor(tireWorst * 100 + 0.5)))
    lineY = lineY - 0.023

    setTextColor(0.88, 0.88, 0.88, 1)
    renderText(x + 0.012, lineY - 0.002, 0.013, string.format(getText("tfl_hud_hours"), spec.operatingHours))
    lineY = lineY - 0.026

    if spec.fault == TrueFarmLifeCondition.FAULT_NONE then
        setTextColor(0.35, 0.90, 0.40, 1)
        renderText(x + 0.012, lineY, 0.013, getText("tfl_status_operational"))
    else
        setTextColor(1.0, 0.28, 0.24, 1)
        renderText(x + 0.012, lineY, 0.013, getText("tfl_fault_" .. spec.fault))
    end

    setTextBold(false)
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextColor(1, 1, 1, 1)
end
