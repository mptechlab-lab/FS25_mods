# Changelog

## 1.3.0.0

- Added the central coordinator for configuration, module API, event history, period events and runtime statistics.
- Linked vehicle faults, inspections and workshop services to the central event record.

## 1.2.0.0

- Added persistent advanced service parts, individual tyre condition/pressure, start interlocks, checklist, and vehicle service history.

## 1.1.0.0 — 2026-09-12

- Quattro profili: Realistico, Hardcore, Simulazione e Ultra Realistico.
- Ogni profilo governa usura, rischio guasti, costo ricambi, lavoro sotto la pioggia e perdita di trazione.
- Aggiunta penalità prestazionale quando si lavora in campo con pioggia significativa.
- In Ultra Realistico il lavoro attivabile è bloccato su terreno troppo bagnato.
- Assicurazione periodica dei mezzi aziendali, proporzionale al valore di acquisto.

## 1.0.0.0 — 2026-09-12

- Prima versione: usura persistente per quattro componenti.
- Guasti a motore, batteria/avviamento, pneumatici, idraulica e attrezzi.
- Integrazione nel preventivo e nella riparazione delle officine standard.
- Pannello diagnostico e azione configurabile.
- Salvataggio per veicolo e sincronizzazione server-client.
